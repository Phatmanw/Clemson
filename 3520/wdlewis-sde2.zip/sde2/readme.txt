Pledge:
On my honor I have neither given nor received aid on this exam

wdlewis-sde2 contains three files; this file(readme.txt), nnr1.log which shows 2
sample uses of each of the required functions, and nnr1.pro.  nnr1.pro contains 
the five required functions:

printList(+H) - takes in a list of lists and prints out each list on a
separate line

theClass(+Avect, -C) - returns the class (last number) of the vector passed in

distanceR2(+V1, +V2, -DistSq) - returns the Euclidean distance (squared) between the 
vectors passed into the function excluding the class

distanceAllVectors2(+V, +Vset, -Dlist) - returns a list of distances from V to each member 
of Vset

nnr1(+Test, +H, -Class) - returns the class of the 1-nearest neighbor of Test in H using the
Euclidean (squared) distance measure.
